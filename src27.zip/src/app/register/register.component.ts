import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { LoginService } from '../login.service';
import { observable } from 'rxjs';
import { Register } from '../register';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  data = false;
  UserForm: any;
  massage: string;

  constructor(private userForm: FormBuilder, private loginService: LoginService) {
    
  }

  createForm() {
    this.UserForm = this.userForm.group({
      fname: ['', Validators.required],
      lname: ['', Validators.required],
      email: ['', Validators.required],
      password: ['', Validators.required],
      designation:['',Validators.required]
    });
  }

  onFormSubmit() {
    const user = this.UserForm.value;
    this.Createemployee(user);
  }
  Createemployee(register: Register) {
    this.loginService.CreateUser(register).subscribe(
      () => {
        this.data = true;
        this.massage = 'Data saved Successfully';
        this.UserForm.reset();
      });
  }   


  ngOnInit() {
    this.createForm();
  }

}
