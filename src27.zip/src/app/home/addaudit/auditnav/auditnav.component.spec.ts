import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuditnavComponent } from './auditnav.component';

describe('AuditnavComponent', () => {
  let component: AuditnavComponent;
  let fixture: ComponentFixture<AuditnavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AuditnavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuditnavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
