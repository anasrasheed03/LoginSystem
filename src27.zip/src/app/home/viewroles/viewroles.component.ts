import { Component, OnInit } from '@angular/core';
import { Service } from 'src/app/services';
import { Roles } from 'src/app/roles';
import { Location } from '@angular/common';


@Component({
  selector: 'app-viewroles',
  templateUrl: './viewroles.component.html',
  styleUrls: ['./viewroles.component.scss']
})
export class ViewrolesComponent implements OnInit {

  constructor(private data: Service,
              private location: Location) { }

  roles: object;
  ngOnInit() {
    this.getRoles();
  }

  getRoles(){
    this.data.getRoles()
    .subscribe(data => this.roles = data);
  }

  // save(): void {
  //   this.data.updateHero(this.roles)
  //     .subscribe(() => this.goBack());
  // }

  // goBack(): void {
  //   this.location.back();
  // }

  // getRoles() {
  //   this.data.getRoles()
  //     .subscribe(data => {
  //       this.roles = data
  //       console.log(this.roles);
  //     }
  //     );
  // }



}
