export class Roles{
    id: number;
    name: string;
}