import { Injectable } from '@angular/core';
import { Roles } from './roles';
import { stages } from './stages';
import { Questions } from './questions';
import { Reports } from './reports';
import { ReportDetails } from './reportdetails';
import { Summary } from './summary';
import { Auditsummary } from './auditsummary';
import { summaryDetail } from './summarydetail';
import { Observable, throwError } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class Service {

  roles: Roles[];
  stages: stages[];
  questions: Questions[];
  reports: Reports[];
  reportDetails: ReportDetails[];
  summary: Summary[];
  auditsummary: Auditsummary[];
  summarydetail: summaryDetail[];
  Url ='http://localhost/Systems/api/';
  constructor(private http:HttpClient) { }
  // getRoles() {
  //   return this.http.get("https://reqres.in/api/users");
  // }
  getRoles(): Observable<Roles[]> {
    return this.http.get(`${this.Url}/roles`).pipe(
      map((res) => {
        this.roles = res['data'];
        return this.roles;
      }),
      catchError(this.handleError));
    
  }
  
  getStages(): Observable<stages[]>{
      return this.http.get(`${this.Url}/stages`).pipe(
      map((res)=>{
        this.stages = res['data'];
        return this.stages;
      }),
      catchError(this.handleError));
  }

  getQuestions(): Observable<Questions[]>{
      return this.http.get(`${this.Url}/questions`).pipe(
        map((res) => {
          this.questions = res['data'];
          return this.questions;
        }),
        catchError(this.handleError));      
  }

  getReports(): Observable<Reports[]> {
    return this.http.get(`${this.Url}/reports`).pipe(
      map((res) => {
        this.reports = res['data'];
        return this.reports;
      }),
      catchError(this.handleError));
  }


  getReportDetails(id: number): Observable<ReportDetails[]> {
   const url = `${this.Url}/reportdetails?id=${id}`;
   return this.http.get<ReportDetails>(url).pipe(
     map((res)=>{
       this.reportDetails = res['data'];
       return this.reportDetails;
     }),
     catchError(this.handleError));
 }


  getSummary(id: number): Observable<Summary[]> {
    const url = `${this.Url}/getchecklist?id=${id}`;
   return this.http.get<Summary>(url).pipe(
     map((res)=>{
       this.summary = res['data'];
       return this.summary;
     }),
     catchError(this.handleError));
 }

  

  getauditsummary(id: number): Observable<Auditsummary[]> {
  const url = `${this.Url}/getsummary?id=${id}`;
    return this.http.get<Auditsummary>(url).pipe(
  map((res) => {
    this.auditsummary = res['data'];
    return this.auditsummary;
  }),
  catchError(this.handleError));
  }

  getsummarydetail(id: number): Observable<summaryDetail[]> {
    const url = `${this.Url}/getsummarydetail?id=${id}`;
    return this.http.get<summaryDetail>(url).pipe(
      map((res) => {
        this.summarydetail = res['data'];
        return this.summarydetail;
      }),
      catchError(this.handleError));
  }

 





  private handleError(error: HttpErrorResponse) {
    console.log(error);

    // return an observable with a user friendly message
    return throwError('Error! something went wrong.');
  }

  
}


