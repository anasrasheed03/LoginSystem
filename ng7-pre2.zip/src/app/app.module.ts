import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavComponent } from './home/nav/nav.component';
import { FormDataService } from './home/addaudit/data/formData.service';
import { WorkflowService } from './home/addaudit/workflow/workflow.service';
import { HomeComponent } from './home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AddauditComponent } from './home/addaudit/addaudit.component';
import { ViewreportsComponent } from './home/viewreports/viewreports.component';
import { ViewrolesComponent } from './home/viewroles/viewroles.component';
import { ViewstagesComponent } from './home/viewstages/viewstages.component';
import { ViewquestionsComponent } from './home/viewquestions/viewquestions.component';
import { ViewreportComponent } from './home/viewreports/viewreport/viewreport.component';

import { AuditnavComponent } from './home/addaudit/auditnav/auditnav.component';
import { BasicComponent } from './home/addaudit/basic/basic.component';
import { Step2Component } from './home/addaudit/step2/step2.component';
import { Step3Component } from './home/addaudit/step3/step3.component';
import { Step4Component } from './home/addaudit/step4/step4.component';
import { Step5Component } from './home/addaudit/step5/step5.component';
import { Step6Component } from './home/addaudit/step6/step6.component'; 

import { ViewchecklistComponent } from './home/viewreports/viewreport/viewchecklist/viewchecklist.component';
import { ViewsummaryComponent } from './home/viewreports/viewreport/viewsummary/viewsummary.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatTabsModule} from '@angular/material/tabs';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatTableModule} from '@angular/material/table';
import { MatStepperModule } from '@angular/material/stepper';
import { MatFormFieldModule } from '@angular/material/form-field';
import { A11yModule } from '@angular/cdk/a11y';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { PortalModule } from '@angular/cdk/portal';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTableModule } from '@angular/cdk/table';
import { CdkTreeModule } from '@angular/cdk/tree';
import { WorkflowGuard } from './home/addaudit/workflow/workflow-guard.service';
import { Select2Module } from 'ng2-select2';
import { GoogleChartsModule } from 'angular-google-charts';  
import {
  MatAutocompleteModule,
  MatBadgeModule,
  MatBottomSheetModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatDividerModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatToolbarModule,
  MatTooltipModule,
  MatTreeModule,
} from '@angular/material';
import { GoogleColumnChartComponent } from './google-column-chart/google-column-chart.component';
import { ProjectsCitiesComponent } from './projects-cities/projects-cities.component';
import { ProjectsRolesComponent } from './projects-roles/projects-roles.component';
import { IndividualStagesComponent } from './individual-stages/individual-stages.component';
import { ProjectCompetencyComponent } from './project-competency/project-competency.component';
import { ProjectStagesComponent } from './project-stages/project-stages.component';
import { ProjectTracksComponent } from './project-tracks/project-tracks.component';

@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    HomeComponent,
    LoginComponent,
    RegisterComponent,
    AddauditComponent,
    ViewreportsComponent,
    ViewrolesComponent,
    ViewstagesComponent,
    ViewquestionsComponent,
    ViewreportComponent,
    AuditnavComponent,
    BasicComponent,
    Step2Component,
    Step3Component,
    Step4Component,
    Step5Component,
    Step6Component,
    ViewchecklistComponent,
    ViewsummaryComponent,
    GoogleColumnChartComponent,
    ProjectsCitiesComponent,
    ProjectsRolesComponent,
    IndividualStagesComponent,
    ProjectCompetencyComponent,
    ProjectStagesComponent,
    ProjectTracksComponent
  ],
  imports: [
    Select2Module,
    BrowserModule,
    AppRoutingModule,
    GoogleChartsModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    BrowserAnimationsModule,
    MatTabsModule,MatExpansionModule,
    MatTableModule, MatStepperModule,
    MatFormFieldModule, A11yModule,
    CdkStepperModule,
    CdkTableModule,
    CdkTreeModule,
    DragDropModule,
    MatAutocompleteModule,
    MatBadgeModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatStepperModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatTreeModule,
    PortalModule,
    ScrollingModule  ],
  providers: [{ provide: FormDataService, useClass: FormDataService },
  { provide: WorkflowService, useClass: WorkflowService }],
  bootstrap: [AppComponent]
})
export class AppModule { }
