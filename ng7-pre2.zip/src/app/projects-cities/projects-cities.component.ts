import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-projects-cities',
  templateUrl: './projects-cities.component.html',
  styleUrls: ['./projects-cities.component.scss']
})
export class ProjectsCitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  title = "Projects (Cities and Number of Projects)";
  type="ColumnChart";
  data1 = [
    ["Karachi", 5],
    ["Lahore", 5]

  ];
  columnNames = ['Cities', 'Projects'];
 
  width=500;
  height=350;
  options ={
    legend: { position: "none" }
  };

  
}
