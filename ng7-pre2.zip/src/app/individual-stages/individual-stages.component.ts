import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-individual-stages',
  templateUrl: './individual-stages.component.html',
  styleUrls: ['./individual-stages.component.scss']
})
export class IndividualStagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  title="Number of Projects by Individual Stage Percentages";
  height=550;
  width=700;
  type="ColumnChart";
  options={
    bar: {groupWidth: "95%"},
    legend: { position: "none" }
  };
  view= [0, 1, { calc: 'stringify', sourceColumn: 1, type: 'string', role: 'annotation' }];

  data=[
    ["Project Initiation", 77.08],
    ["Project Planning", 58.34],
    ["Project Initiation", 77.08],
    ["Project Planning", 58.34],
    ["Project Planning", 58.34],
    ["Project Initiation", 77.08],
    ["Project Planning", 58.34],
    ["Project Planning", 58.34],
    ["Project Initiation", 77.08],
    ["Project Planning", 58.34],
    ["Change Management", 85]
  ];
}
