import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-competency',
  templateUrl: './project-competency.component.html',
  styleUrls: ['./project-competency.component.scss']
})
export class ProjectCompetencyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

title="Graph by Competency";
  width=1200;
  height=400;
  options={
    is3D:true
  }
  data = [
    ["Digital Ecommerce",2],
    ["Digital Framework",3],
    ["Enterprise Services",2],
    ["Technology Services",3]
  ];
  type="PieChart";
  columnNames = ['Competency', 'Projects'];

  
  
   
}
