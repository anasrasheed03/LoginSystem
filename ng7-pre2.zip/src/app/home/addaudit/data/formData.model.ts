export class FormData {
    customer: string = '';
    tracks : string = '';
    location: string = '';
    competency: string='';
    project: string='';
    projectManager: string = '';
    Lead: string = '';
    qaLead: string = '';
    auditor: string = '';
    auditDate: string = '';
    remarks: string = '';
    question: any = {};
    Evidence: any = {};
    Verified: any = {};
    TotalPoints: any = {};
    AttainedPoints: any = {};
    exception: any = {};
    nc: any = {};
    stages: any = {};
    observation: any = {};
    NonConformanceSummary :any ={};
    type: any ={};
    owner: any ={};
    phase: any = {};
    Observations: any = {};
    


    clear() {
        this.customer = '';
        this.tracks = '';
        this.location = '';
        this.competency='';
        this.projectManager = '';
        this.Lead = '';
        this.qaLead = '';
        this.auditor = '';
        this.auditDate = '';
        this.remarks = '';
        this.project = '';
        this.question = {};
        this.Evidence = {};
        this.Verified = {};
        this.TotalPoints = {};
        this.AttainedPoints = {};
        this.exception = {};
        this.nc = {};
        this.stages = {};
        this.observation = {};
        this.NonConformanceSummary={};
        this.type = {};
        this.owner = {};
        this.phase = {};
        this.Observations = {};

    }
}

export class basic {
    customer: string = '';
    tracks : string = '';
    location: string = '';
    project: string ='';
    competency: string = '';
}


export class step2 {
    projectManager: string = '';
    Lead: string = '';
    qaLead: string = '';
    auditor: string = '';
    auditDate: string = '';
    
}

export class step3 {
    remarks: string = '';
   
}

export class step4 {
    question: any={};
    Evidence: any = {};
    Verified: any= {};
    TotalPoints: any = {};
    AttainedPoints: any = {};
    exception: any = {};
    nc: any = {};
    stages: any = {};
    observation: any = {};

}
export class step5 {
    NonConformanceSummary : any ={};
    type: any ={}
    owner: any ={}
    phase: any = {}

}
export class step6 {
    Observations: any = {};

}