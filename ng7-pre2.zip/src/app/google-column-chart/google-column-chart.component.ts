import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-google-column-chart',
  templateUrl: './google-column-chart.component.html',
  styleUrls: ['./google-column-chart.component.scss']
})
export class GoogleColumnChartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  title = 'Company Hiring Report';  
  type = 'ColumnChart';  
  data1 = [  
     ["2014", 200],  
     ["2015", 560],  
     ["2016", 280],  
     ["2017", 300],  
     ["2018", 600]  
  ];  
  columnNames = ['Year', 'India'];  
  options = {};  
  width = 600;  
  height = 400;

}
