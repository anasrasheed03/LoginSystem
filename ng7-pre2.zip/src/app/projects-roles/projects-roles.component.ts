import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-projects-roles',
  templateUrl: './projects-roles.component.html',
  styleUrls: ['./projects-roles.component.scss']
})
export class ProjectsRolesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  title= "Graph by Roles";
  type="PieChart";
  data=[
    ["Project Management", 66.30],
    ["Software Engineering", 56.40]
  ];
  options={
    pieHole: 0.4
  };
  width=500;
  height=350;

  
}
