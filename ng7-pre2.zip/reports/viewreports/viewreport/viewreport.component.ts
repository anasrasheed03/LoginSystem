import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location  } from '@angular/common';
import { Service } from 'src/app/services';

@Component({
  selector: 'app-viewreport',
  templateUrl: './viewreport.component.html',
  styleUrls: ['./viewreport.component.scss']
})
export class ViewreportComponent implements OnInit {
reportDetail;
summary;
total;
totl;
  constructor(private activatedRoute: ActivatedRoute, 
    private audit: Service,
    private reportDetails: Service,
              private location: Location
  ) { }

  ngOnInit() {
    this.getreportDetail();
    this.getSummary();
    
      }

  getreportDetail(){
    const id= +this.activatedRoute.snapshot.paramMap.get('id');
    this.reportDetails.getReportDetails(id)
    .subscribe(reportsDetail=>this.reportDetail=reportsDetail);
  }

  getSummary() {
    const id = +this.activatedRoute.snapshot.paramMap.get('id');
    this.audit.getSummary(id)
      .subscribe(summary => this.summary = summary);
  }

  getTotal(totl){
    this.total=totl;

  }


  onBack(){
    this.location.back();
  }

}
