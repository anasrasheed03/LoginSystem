<?php

if ($_SERVER['REQUEST_METHOD']=='POST') {

    $userName = $_POST['userName'];   
    $password = $_POST['Password'];

    require_once 'data.php';

    $sql = "SELECT * FROM tbl_login WHERE username='$userName'";

    $response = mysqli_query($con, $sql);

    $result = array();
    $result['username'] = array();
    
    if ( mysqli_num_rows($response) == 1 ) {
        
        $row = mysqli_fetch_assoc($response);

        if ( $password === $row['password']) {
            
            
            $result['success'] = "1";
            $result['message'] = "success";
            echo json_encode($result);

            mysqli_close($con);

        } else {

            $result['success'] = "0";
            $result['message'] = "error";
            echo json_encode($result);

            mysqli_close($con);

        }

    }

}

?>