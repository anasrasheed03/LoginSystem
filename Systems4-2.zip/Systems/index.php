<?php include('config/header.php');
?>
 <style type="text/css">
        .hide,.canvasjs-chart-credit{
             display:none !important;
        }             
    </style>
<br/>
<br/>
<br/>

<br/>
<br/>
<br/>
<br/>


  <div id="chart-container">FusionCharts will render here</div>
  <script src="scripts/js/jquery-2.1.4.js"></script>
  <script src="scripts/js/fusioncharts.js"></script>
  <script src="scripts/js/themes/fusioncharts.theme.zune.js"></script>
  <script src="scripts/js/app.js"></script>

<script>
	document.getElementsByTagName('tspan')[13].setAttribute("class", "hide");
</script>

<br/>

<div>
	<!DOCTYPE HTML>
<html>
<head>
	<?php
 
$dataPoints = array( 
	array("label"=>"Project Management", "symbol" => "Project Management","y"=>46.6),
	array("label"=>"Software Engineering", "symbol" => "Software Engineering","y"=>27.7),
	array("label"=>"Development", "symbol" => "Development","y"=>13.9),
	array("label"=>"Quality Assurance", "symbol" => "Quality Assurance","y"=>5),
	
 
)
 
?>
<script>
window.onload = function() {
 
var chart = new CanvasJS.Chart("chartContainer", {
	theme: "light2",
	animationEnabled: true,
	title: {
		text: "Chart by Roles"
	},
	data: [{
		type: "doughnut",
		indexLabel: "{symbol} - {y}",
		yValueFormatString: "#,##0.0\"%\"",
		showInLegend: true,
		legendText: "{label} : {y}",
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();
 
}
</script>
</head>
<body>
<div id="chartContainer" style="height: 370px; width: 100%;"></div>
<script src="scripts/test.js"></script>
</body>
</html>        

</div>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>

<br/>
<br/>
<br/>

<?php include('config/footer.php');?>