import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AddauditComponent } from './home/addaudit/addaudit.component';
import { ViewquestionsComponent } from './home/viewquestions/viewquestions.component';
import { ViewreportsComponent } from './home/viewreports/viewreports.component';
import { ViewrolesComponent } from './home/viewroles/viewroles.component';
import { ViewstagesComponent } from './home/viewstages/viewstages.component';
import { ViewreportComponent } from './home/viewreports/viewreport/viewreport.component';
import { ViewchecklistComponent } from './home/viewreports/viewreport/viewchecklist/viewchecklist.component';
import { ViewsummaryComponent  } from './home/viewreports/viewreport/viewsummary/viewsummary.component'

const routes: Routes = [
  {path:'', component: LoginComponent,
    data: { title: 'Login - Systems Audit System' }},
  {path:'register', component: RegisterComponent,
    data: { title: 'Register - Systems Audit System' }},
  {path:'home', component: HomeComponent,
    data: { title: 'Home - Systems' },
    children: [
      { 
        path:'newAudit', component: AddauditComponent,
         data: { title: 'Add New Audit - Systems' }
      },      
      {
        path: 'viewreports', component: ViewreportsComponent,
        data: { title: 'Audit Reports - Systems' }
      },
      {
        path: 'viewreport/:id', component: ViewreportComponent,
        data: { title: 'Audit Report - Systems' },
        children: [
          {
          path:'', component: ViewchecklistComponent, pathMatch:'full',
          data: { title: 'Questions List' }
          },
          {
            path: 'viewchecklist', component: ViewchecklistComponent,
            data: { title: 'Questions List' }
          },
          {
            path:'viewsummary/:id', component: ViewsummaryComponent,
            data: { title: 'View Audit Summary' }
          }
        ]
      },
      {
        path:'viewquestions', component: ViewquestionsComponent,
        data: { title: 'Questions List' }
      },
      {
      path:'viewroles', component:ViewrolesComponent,
      data: { title: 'Roles List' }
      },
      {
      path:'viewstages', component:ViewstagesComponent,
      data: { title: 'Stages List' }
      }
      
    ]
},
  
];






@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
