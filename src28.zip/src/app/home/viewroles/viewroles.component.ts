import { Component, OnInit } from '@angular/core';
import { Service } from 'src/app/services';
import { Roles } from 'src/app/roles';
import { Location } from '@angular/common';


@Component({
  selector: 'app-viewroles',
  templateUrl: './viewroles.component.html',
  styleUrls: ['./viewroles.component.scss']
})
export class ViewrolesComponent implements OnInit {
  success;
  error;
  constructor(private data: Service,
              private location: Location) { }

  roles: object;
  ngOnInit() {
    this.getRoles();
  }

  // getRoles(){
  //   this.data.getRoles()
  //   .subscribe(data => this.roles = data);
  // }



  getRoles(): void {
    this.data.getRoles().subscribe(
      (res: Roles[]) => {
        this.roles = res;
      },
      (err) => {
        this.error = err;
      }
    );
  }
  

  updateRoles(role_name, id) {
        this.resetErrors();  
    this.data.updaterole({ name: role_name.value,  id: +id })
      .subscribe(
      (res) => {
        this.roles = res;
        this.success = 'Updated successfully';
      },
      (err) => this.error = err
      );
  }


  deleteRoles(id) {
       this.resetErrors();
    this.data.deleterole(+id)
      .subscribe(
      (res: Roles[]) => {
        this.roles = res;
        this.success = 'Deleted successfully';
      },
      (err) => this.error = err
      );
  }
  role = new Roles();
  addRole(f) {
    this.resetErrors();

    this.data.addRole(this.role)
      .subscribe(
      (res: Roles[]) => {
        // Update the list of Roles
        this.roles = res;

        // Inform the user
        this.success = 'Created successfully';

        // Reset the form
        f.reset();
      },
      (err) => this.error = err
      );
  }

  private resetErrors() {
    this.success = '';
    this.error = '';
  }




}
