import { Component, OnInit } from '@angular/core';
import { stages } from 'src/app/stages';
import { Service } from 'src/app/services';

@Component({
  selector: 'app-viewstages',
  templateUrl: './viewstages.component.html',
  styleUrls: ['./viewstages.component.scss']
})
export class ViewstagesComponent implements OnInit {

  stages: object;

  constructor(private stage: Service) { }

  ngOnInit() {
    this.getStages();
  }

  getStages(){
    this.stage.getStages()
      .subscribe(stage => this.stages = stage);
  }

}
