import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location  } from '@angular/common';
import { Service } from 'src/app/services';

@Component({
  selector: 'app-viewreport',
  templateUrl: './viewreport.component.html',
  styleUrls: ['./viewreport.component.scss']
})
export class ViewreportComponent implements OnInit {
reportDetail;
summary;
  constructor(private activatedRoute: ActivatedRoute, 
    private reportDetails: Service,
              private location: Location
  ) { }

  ngOnInit() {
    this.getreportDetail();
 
          }

  getreportDetail(){
    const id= +this.activatedRoute.snapshot.paramMap.get('id');
    this.reportDetails.getReportDetails(id)
    .subscribe(reportsDetail=>this.reportDetail=reportsDetail);
  }



  

  onBack(){
    this.location.back();
  }

}
