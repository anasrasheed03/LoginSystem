import { Component, OnInit } from '@angular/core';
import { Service } from 'src/app/services';

@Component({
  selector: 'app-viewquestions',
  templateUrl: './viewquestions.component.html',
  styleUrls: ['./viewquestions.component.scss']
})
export class ViewquestionsComponent implements OnInit {
  questions: object;
  constructor(private question: Service) { }

  ngOnInit() {
    this.getQuestion();
  }

  getQuestion(){
    this.question.getQuestions()
    .subscribe(question => this.questions = question);
  }

}
