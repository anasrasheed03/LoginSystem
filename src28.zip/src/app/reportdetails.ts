export class ReportDetails{
    Customer: string;
    location: string;
    competency: string;
    projectName: string;
    aduitDate: string;
    id: number;
    tracks: string;
    projectManager: string;
    Lead: string;
    qaLead: string;
    auditor: string;
    Total_NC: number;
    remarks: string;
}