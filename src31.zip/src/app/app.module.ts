import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavComponent } from './home/nav/nav.component';

import { HomeComponent } from './home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AddauditComponent } from './home/addaudit/addaudit.component';
import { ViewreportsComponent } from './home/viewreports/viewreports.component';
import { ViewrolesComponent } from './home/viewroles/viewroles.component';
import { ViewstagesComponent } from './home/viewstages/viewstages.component';
import { ViewquestionsComponent } from './home/viewquestions/viewquestions.component';
import { ViewreportComponent } from './home/viewreports/viewreport/viewreport.component';

import { AuditnavComponent } from './home/addaudit/auditnav/auditnav.component';
import { BasicComponent } from './home/addaudit/basic/basic.component';
import { Step2Component } from './home/addaudit/step2/step2.component';
import { Step3Component } from './home/addaudit/step3/step3.component';
import { Step4Component } from './home/addaudit/step4/step4.component';
import { Step5Component } from './home/addaudit/step5/step5.component';
import { Step6Component } from './home/addaudit/step6/step6.component'; 
import { FormsModule } from '@angular/forms';
import { ViewchecklistComponent } from './home/viewreports/viewreport/viewchecklist/viewchecklist.component';
import { ViewsummaryComponent } from './home/viewreports/viewreport/viewsummary/viewsummary.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatTabsModule} from '@angular/material/tabs';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatTableModule} from '@angular/material/table';

@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    HomeComponent,
    LoginComponent,
    RegisterComponent,
    AddauditComponent,
    ViewreportsComponent,
    ViewrolesComponent,
    ViewstagesComponent,
    ViewquestionsComponent,
    ViewreportComponent,
    AuditnavComponent,
    BasicComponent,
    Step2Component,
    Step3Component,
    Step4Component,
    Step5Component,
    Step6Component,
    ViewchecklistComponent,
    ViewsummaryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    BrowserAnimationsModule,
    MatTabsModule,MatExpansionModule,
    MatTableModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
