import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../login.service';
import { FormsModule } from '@angular/forms';   

import { Login } from '../loginclass';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm: any;
  constructor(private router: Router, private LoginForm: FormBuilder, private loginService: LoginService) {
   
  }

 
  model: any = {}; 
  data=false;
  massage;
  
    
  

  loginform(){
    this.loginForm = this.LoginForm.group({
      username: ['',Validators.required],
      password: ['',Validators.required]
    });
  }

  onFormSubmit() {
    const data = this.loginForm.value;


    this.Login(data);
    console.log(data);
  }
  Login(login: Login) {
    this.loginService.Login(login).subscribe(
      () => {

        this.data = true;
        this.massage = 'Data saved Successfully';
        this.router.navigate(['/home']);
      });
  }
  ngOnInit() {
    this.loginform();
  } 

 

  // login() {
  //   debugger;
  //   this.loginService.Login(this.model).subscribe(
  //     result => {
  //       debugger;
  //       if (result.Status == "Success") {
  //         this.router.navigate(['/home']);
  //         debugger;
  //       }
  //       else {
  //         this.errorMessage = result.Message;
  //       }
  //     },
  //     error => {
  //       this.errorMessage = error.message;
  //     });
  // };    
}
