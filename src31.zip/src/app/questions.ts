export class Questions{
    question_id: number;
    question: string;
    Total_Points: number;
    
}