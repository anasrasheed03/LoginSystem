import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Service } from 'src/app/services';

@Component({
  selector: 'app-viewchecklist',
  templateUrl: './viewchecklist.component.html',
  styleUrls: ['./viewchecklist.component.scss']
})
export class ViewchecklistComponent implements OnInit {
summary;
  constructor(private activatedRoute: ActivatedRoute,
    private audit: Service,
    private location: Location) { }

  ngOnInit() {
    this.getSummary();
  }

  getSummary() {
    const id = +this.activatedRoute.snapshot.paramMap.get('id');
    this.audit.getSummary(id)
      .subscribe(summary => this.summary = summary);
  }
}
