export class Reports{
    Customer: string;
    location: string;
    competency: string;
    projectName: string;
    aduitDate: string;
    id: number;
}