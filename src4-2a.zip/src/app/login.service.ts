import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { from, Observable, BehaviorSubject } from 'rxjs';
import { Register } from './register';
import { Login } from './loginclass';
@Injectable({
  providedIn: 'root'
})
export class LoginService {
  register: Register[];
  Url: string;
  token: string;
  header: any;
  login: Login[];

  constructor(private http: HttpClient) {
    this.Url = 'http://localhost/Systems/api';
    const headerSettings: { [name: string]: string | string[]; } = {};
    this.header = new HttpHeaders(headerSettings);

   }
   
  
  Login(login: Login): Observable<Login[]> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post<Login[]>
      (this.Url + '/UserLogin.php', { data: login }, httpOptions)

  } 
  
  
  CreateUser(register: Register): Observable<Register[]> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post<Register[]>
      (this.Url + '/create.php', { data: register }, httpOptions)
    
  }  
}

