export class FormData {
    customer: string = '';
    tracks : string = '';
    location: string = '';
    competency: string='';
    project: string='';
    projectManager: string = '';
    Lead: string = '';
    qaLead: string = '';
    auditor: string = '';
    auditDate: string = '';
    remarks: string = '';
    


    clear() {
        this.customer = '';
        this.tracks = '';
        this.location = '';
        this.competency='';
        this.projectManager = '';
        this.Lead = '';
        this.qaLead = '';
        this.auditor = '';
        this.auditDate = '';
        this.remarks = '';
        this.project = '';
    }
}

export class basic {
    customer: string = '';
    tracks : string = '';
    location: string = '';
    project: string ='';
    competency: string = '';
}


export class step2 {
    projectManager: string = '';
    Lead: string = '';
    qaLead: string = '';
    auditor: string = '';
    auditDate: string = '';
    
}

export class step3 {
    remarks: string = '';
   
}

export class step4 {
    remarks: string = '';

}
export class step5 {
    remarks: string = '';

}
export class step6 {
    remarks: string = '';

}