export class Summary{
    id: number;
    Evidence: string;
    Verified: string;
    Total_Points: number;
    Points_Attained: number;
    Exception_Deviation: number;
    NC: number;
    Observation: String;
    qestion: string;
    project_total: number;

}