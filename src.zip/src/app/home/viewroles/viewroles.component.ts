import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewroles',
  templateUrl: './viewroles.component.html',
  styleUrls: ['./viewroles.component.scss']
})
export class ViewrolesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
