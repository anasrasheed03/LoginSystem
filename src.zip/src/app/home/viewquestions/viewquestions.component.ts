import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewquestions',
  templateUrl: './viewquestions.component.html',
  styleUrls: ['./viewquestions.component.scss']
})
export class ViewquestionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
