import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addaudit',
  templateUrl: './addaudit.component.html',
  styleUrls: ['./addaudit.component.scss']
})
export class AddauditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}