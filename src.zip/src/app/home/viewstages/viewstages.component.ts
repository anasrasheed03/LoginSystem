import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewstages',
  templateUrl: './viewstages.component.html',
  styleUrls: ['./viewstages.component.scss']
})
export class ViewstagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
