import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewstagesComponent } from './viewstages.component';

describe('ViewstagesComponent', () => {
  let component: ViewstagesComponent;
  let fixture: ComponentFixture<ViewstagesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewstagesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewstagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
