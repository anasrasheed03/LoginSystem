import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewreports',
  templateUrl: './viewreports.component.html',
  styleUrls: ['./viewreports.component.scss']
})
export class ViewreportsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
