import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewreport',
  templateUrl: './viewreport.component.html',
  styleUrls: ['./viewreport.component.scss']
})
export class ViewreportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
