import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavComponent } from './home/nav/nav.component';

import { HomeComponent } from './home/home.component';
import {HttpClientModule} from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AddauditComponent } from './home/addaudit/addaudit.component';
import { ViewreportsComponent } from './home/reports/viewreports/viewreports.component';
import { ViewrolesComponent } from './home/viewroles/viewroles.component';
import { ViewstagesComponent } from './home/viewstages/viewstages.component';
import { ViewquestionsComponent } from './home/viewquestions/viewquestions.component';
import { ViewreportComponent } from './home/reports/viewreports/viewreport/viewreport.component';
import { ReportsComponent } from './home/reports/reports.component'; 

@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    HomeComponent,
    LoginComponent,
    RegisterComponent,
    AddauditComponent,
    ViewreportsComponent,
    ViewrolesComponent,
    ViewstagesComponent,
    ViewquestionsComponent,
    ViewreportComponent,
    ReportsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
