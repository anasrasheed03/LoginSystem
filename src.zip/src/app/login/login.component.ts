import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(private loginForm: FormBuilder) {
    this.loginform();
  }

  ngOnInit() {
  }

  loginform(){
    this.LoginForm=this.loginForm.group({
      username: ['',Validators.required],
      password: ['',Validators.required]
    });
  }

}
