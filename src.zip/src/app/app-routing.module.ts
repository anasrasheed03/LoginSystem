import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AddauditComponent } from './home/addaudit/addaudit.component';
import { ViewquestionsComponent } from './home/viewquestions/viewquestions.component';
import { ViewreportsComponent } from './home/reports/viewreports/viewreports.component';
import { ViewrolesComponent } from './home/viewroles/viewroles.component';
import { ViewstagesComponent } from './home/viewstages/viewstages.component';
import { ViewreportComponent } from './home/reports/viewreports/viewreport/viewreport.component';
import { ReportsComponent } from './home/reports/reports.component'
const routes: Routes = [
  {path:'', component: LoginComponent,
    data: { title: 'Login - Systems Audit System' }},
  {path:'register', component: RegisterComponent,
    data: { title: 'Register - Systems Audit System' }},
  {path:'home', component: HomeComponent,
    data: { title: 'Home - Systems' },
    children: [
      { 
        path:'newAudit', 
        component: AddauditComponent,
        data: { title: 'Add New Audit - Systems' }
      },
      {
        path:'reports',
        component: ReportsComponent,
        data: { title: 'Audit Reports - Systems' },
        children: [
          {
            path: 'viewreports',
            component: ViewreportsComponent,
            data: { title: 'Audit Reports - Systems' }
          },
            {
                path: 'viewreport',
                component: ViewreportComponent,
                data: { title: 'Audit Report - Systems' }
            }
            ]
          },      
           
              {
                path:'viewquestions',
                component: ViewquestionsComponent,
                data: { title: 'Questions List' }
              },
              {
                path:'viewroles',
                component:ViewrolesComponent,
                data: { title: 'Roles List' }
              },
              {
                path:'viewstages',
                component:ViewstagesComponent,
                data: { title: 'Stages List' }
              }
      
    ]
},
  
];






@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
