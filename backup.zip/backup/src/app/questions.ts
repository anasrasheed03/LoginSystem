export class Questions{
    question: string;
    Total_Points: number;
    question_id: number;
    stage_name: string;
  
}