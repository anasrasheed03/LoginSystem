export class Register {
    fname: string;
    lname: string;
    email: string;
    password: string;
    designation: string
} 