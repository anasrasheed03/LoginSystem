import { Component, OnInit } from '@angular/core';
import { Service } from 'src/app/services';
import { Questions } from 'src/app/questions';

@Component({
  selector: 'app-viewquestions',
  templateUrl: './viewquestions.component.html',
  styleUrls: ['./viewquestions.component.scss']
})
export class ViewquestionsComponent implements OnInit {
  questions: object;
  success;
  error;
  constructor(private question: Service) { }

  ngOnInit() {
    this.getQuestion();
  }

  // getQuestion(){
  //   this.question.getQuestions()
  //   .subscribe(question => this.questions = question);
  // }
  getQuestion(): void {
    this.question.getQuestions().subscribe(
      (res: Questions[]) => {
        this.questions = res;
      },
      (err) => {
        this.error = err;
      }
    );
  }


  // updatequestion(question, question_id) {
  //   this.resetErrors();
  //   console.log(question_id);
  //   this.question.updatequestion({ question: question, question_id: +question_id })
  //     .subscribe(
  //     (res) => {
  //       this.questions = res;
  //       this.success = 'Updated successfully';
  //     },
  //     (err) => this.error = err
  //     );
  // }

  deletequestion(id) {
    this.resetErrors();
    this.question.deletequestion(+id)
      .subscribe(
      (res: Questions[]) => {
        this.questions = res;
        this.success = 'Deleted successfully';
      },
      (err) => this.error = err
      );
  }

  private resetErrors() {
    this.success = '';
    this.error = '';
  }


}
