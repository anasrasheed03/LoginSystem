import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auditnav',
  templateUrl: './auditnav.component.html',
  styleUrls: ['./auditnav.component.scss']
})
export class AuditnavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
