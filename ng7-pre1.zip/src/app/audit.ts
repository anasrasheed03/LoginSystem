export class audit {     
    tracks: string;     
    location: string;     
    competency: string;     
    project: string;     
    projectManager: string;     
    Lead: string;
    qaLead: string;     
    auditor: string;     
    auditDate: string;     
    remarks: string;     
    customer: string } 