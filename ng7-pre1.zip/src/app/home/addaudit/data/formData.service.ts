import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { from, Observable, BehaviorSubject } from 'rxjs';


import { audit } from 'src/app/audit';
import { FormData, basic, step2, step3, step4, step5, step6 }       from './formData.model';
import { WorkflowService }                   from '../workflow/workflow.service';
import { STEPS }                             from '../workflow/workflow.model';

@Injectable()
export class FormDataService {

    Url: any;
    header: any;
    reports: audit[];
    private formData: FormData = new FormData();
    private isbasicFormValid: boolean = false;
    private isstep2FormValid: boolean = false;
    private isstep3FormValid: boolean = false;
    private isstep4FormValid: boolean = false;
    private isstep5FormValid: boolean = false;
    private isstep6FormValid: boolean = false;

    constructor(private workflowService: WorkflowService) { 
        
        

    }

    getbasic(): basic {
        // Return the Personal data
        var basic: basic = {
            customer: this.formData.customer,
            tracks: this.formData.tracks,
            location: this.formData.location,
            project: this.formData.project,
            competency: this.formData.competency
        };
        return basic;
    }

    setbasic(data: basic) {
        // Update the Personal data only when the Personal Form had been validated successfully
        this.isbasicFormValid = true;
        this.formData.customer = data.customer;
        this.formData.tracks = data.tracks;
        this.formData.location = data.location;
        this.formData.project = data.project;
        this.formData.competency = data.competency;
        // Validate Personal Step in Workflow
        this.workflowService.validateStep(STEPS.basic);
    }

    getstep2(): step2 {
        // Return the Personal data
        var step2: step2 = {
            projectManager: this.formData.projectManager,
            Lead: this.formData.Lead,
            qaLead: this.formData.qaLead,
            auditor: this.formData.auditor,
            auditDate: this.formData.auditDate
            
        };
        return step2;
    }
    
    setstep2(data: step2) {
        // Update the work type only when the Work Form had been validated successfully
        this.isstep2FormValid = true;
        this.formData.projectManager = data.projectManager;
        this.formData.Lead = data.Lead;
        this.formData.qaLead = data.qaLead;
        this.formData.auditor = data.auditor;
        this.formData.auditDate = data.auditDate;
        // Validate Work Step in Workflow
        this.workflowService.validateStep(STEPS.step2);
    }

    getstep3() : step3 {
        // Return the Address data
        var step3: step3 = {
            remarks: this.formData.remarks,
            
        };
        return step3;
    }

    setstep3(data: step3) {
        // Update the Address data only when the Address Form had been validated successfully
        this.isstep3FormValid = true;
        this.formData.remarks = data.remarks;
        // Validate Address Step in Workflow
        this.workflowService.validateStep(STEPS.step3);
    }

    getstep4(): step4 {
        // Return the Address data
        var step4: step4 = {
            question: this.formData.question,
            Evidence: this.formData.Evidence,
            Verified: this.formData.Verified,
            TotalPoints: this.formData.TotalPoints,
            AttainedPoints: this.formData.AttainedPoints,
            exception: this.formData.exception,
            nc: this.formData.nc,
            stages: this.formData.stages,
            observation: this.formData.observation

        };
        return step4;
    }

    setstep4(data: step4) {
        // Update the Address data only when the Address Form had been validated successfully
        this.isstep4FormValid = true;
        this.formData.question = data.question;
        this.formData.Evidence = data.Evidence;
        this.formData.Verified = data.Verified;
        this.formData.TotalPoints = data.TotalPoints;
        this.formData.AttainedPoints = data.AttainedPoints;
        this.formData.exception = data.exception;
        this.formData.nc = data.nc;
        this.formData.stages = data.stages;
        this.formData.observation = data.observation;
        // Validate Address Step in Workflow
        this.workflowService.validateStep(STEPS.step3);
    }

    getFormData(): FormData {
        // Return the entire Form Data
        return this.formData;
        
    }



    resetFormData(): FormData {
           
        // Reset the workflow
        this.workflowService.resetSteps();
        // Return the form data after all this.* members had been reset
        this.formData.clear();
        this.isbasicFormValid = this.isstep2FormValid = this.isstep3FormValid = false;
        return this.formData;
    }

    isFormValid() {
        // Return true if all forms had been validated successfully; otherwise, return false
        return this.isbasicFormValid &&
            this.isstep2FormValid && 
            this.isstep3FormValid;
    }
    
    
}