import { Component, OnInit } from '@angular/core';
import { Questions } from 'src/app/questions';
import { Service } from 'src/app/services';
import { Roles } from 'src/app/roles';
import { stages } from 'src/app/stages';
import { FormDataService } from '../data/formData.service';
import { Router } from '@angular/router';
import { step4 } from '../data/formData.model';

@Component({
  selector: 'app-step4',
  templateUrl: './step4.component.html',
  styleUrls: ['./step4.component.scss']
})
export class Step4Component implements OnInit {
  //evidence:any[]={};
  
  name: string;
  position: number;
  weight: number;
  symbol: string;
  questions: object;
  success;
  error;
  roles: object;
  stages: object;
  stage_names = ['Project Management', 'Software-Engineering', 'Development', 'Quality Assurance'];
  displayedColumns: string[] = ['name', 'weight', 'symbol','points','attained','exception','nc','observation'];
  dataSource: object;
  
  Verified: any={};
  step4: step4;
  form: any;


  constructor(private question: Service, private data: Service, private stage: Service, 
    private service: FormDataService, private router:Router) { }

  ngOnInit() {
    this.getQuestion();
    this.getRoles();
    this.getStages();
    this.stage_names;
    this.step4 = this.service.getstep4();
    console.log('Step4 features loaded!');
  }

 new;
  onchange(event) {
    const newVal = event.target.value;
    //this.new = newVal.slice(8,9);
    console.log(newVal);
  }

  getQuestion(): void {
    this.question.getQuestions().subscribe(
      (res: Questions[]) => {
        this.dataSource = res;
      },
      (err) => {
        this.error = err;
      }
    );
  }

  getRoles(): void {
    this.data.getRoles().subscribe(
      (res: Roles[]) => {
        this.roles = res;
      },
      (err) => {
        this.error = err;
      }
    );
  }

  getStages(): void {
    this.stage.getStages().subscribe(
      (res: stages[]) => {
        this.stages = res;
      },
      (err) => {
        this.error = err;
      }
    );
  }

  save(form: any): boolean {
    if(!form.valid){
      return false;
    }
    this.service.setstep4(this.step4);
    return true;
  }
 
  goToNext(form: any) {
    if (this.save(form)) {
      this.router.navigate(['/home/newAudit/step5']);
    }
  }

  goToPrevious(form: any) {
    if (this.save(form)) {
      this.router.navigate(['home/newAudit/step3']);
    }
  }

}
 