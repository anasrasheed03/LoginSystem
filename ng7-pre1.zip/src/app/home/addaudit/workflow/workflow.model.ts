export const STEPS = {
    basic: 'basic',
    step2: 'step2',
    step3: 'step2',
    step4: 'step4',
    step5: 'step5',
    step6: 'step6'
}
