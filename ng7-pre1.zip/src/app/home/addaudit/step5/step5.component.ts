import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-step5',
  templateUrl: './step5.component.html',
  styleUrls: ['./step5.component.scss']
})
export class Step5Component implements OnInit {
  nc1;
  constructor(private router:Router) { }

  ngOnInit() {
  }
Arr = Array;
  addNC(n:any){
   this.nc1 = n;
    console.log(this.nc1);
  }

  phases= ["Project Initiation","Project Planning","Project Monitoring","Requirement Analysis","Requirement Analysis","Change Management","Technical Design","Code Writing","Unit Testing","Internal Release","Test Planning & Designing","QA Acceptance & System Testing"];

  // save(form: any): boolean {
  //   if(!form.valid){
  //     return false;
  //   }
  //   this.service.setstep4(this.step4);
  //   return true;
  // }
 
  goToNext() {
         this.router.navigate(['/home/newAudit/step6']);
    
  }

  goToPrevious() {
         this.router.navigate(['home/newAudit/step4']);
   
  }

}

