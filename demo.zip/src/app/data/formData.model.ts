export class FormData {
    customer: string = '';
    tracks : string = '';
    location: string = '';
    competency: string='';
    project: string='';
    work: string = '';
    street: string = '';
    city: string = '';
    state: string = '';
    zip: string = '';


    clear() {
        this.customer = '';
        this.tracks = '';
        this.location = '';
        this.competency='';
        this.work = '';
        this.street = '';
        this.city = '';
        this.state = '';
        this.zip = '';
        this.project = '';
    }
}

export class Personal {
    customer: string = '';
    tracks : string = '';
    location: string = '';
    project: string ='';
    competency: string = '';
}

export class Address {
    street: string = '';
    city: string = '';
    state: string = '';
    zip: string = '';
}