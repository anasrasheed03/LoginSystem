import { Component, OnInit } from '@angular/core';
import { Questions } from 'src/app/questions';
import { Service } from 'src/app/services';
import { Roles } from 'src/app/roles';
import { stages } from 'src/app/stages';

@Component({
  selector: 'app-step4',
  templateUrl: './step4.component.html',
  styleUrls: ['./step4.component.scss']
})
export class Step4Component implements OnInit {

  name: string;
  position: number;
  weight: number;
  symbol: string;
  questions: object;
  success;
  error;
  roles: object;
  stages: object;
  stage_names = ['Project Management', 'Software-Engineering', 'Development', 'Quality Assurance'];
  displayedColumns: string[] = ['name', 'weight', 'symbol','points','attained','exception','nc','observation'];
  dataSource: object;


  constructor(private question: Service, private data: Service, private stage: Service) { }

  ngOnInit() {
    this.getQuestion();
    this.getRoles();
    this.getStages();
    this.stage_names;
  }

  getQuestion(): void {
    this.question.getQuestions().subscribe(
      (res: Questions[]) => {
        this.dataSource = res;
      },
      (err) => {
        this.error = err;
      }
    );
  }

  getRoles(): void {
    this.data.getRoles().subscribe(
      (res: Roles[]) => {
        this.roles = res;
      },
      (err) => {
        this.error = err;
      }
    );
  }

  getStages(): void {
    this.stage.getStages().subscribe(
      (res: stages[]) => {
        this.stages = res;
      },
      (err) => {
        this.error = err;
      }
    );
  }
  verified;
  Tpoint;
  Apoint;
  onchange(){
    if (this.verified === 'Yes') {

    } else if (this.verified === 'No') {
      this.Apoint = 0;
    } else if (this.verified === 'N/A') {
      this.Tpoint = 0;
      this.Apoint = 0;
    }

  }
}
 