import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router  } from '@angular/router';

@Component({
  selector: 'app-basic',
  templateUrl: './basic.component.html',
  styleUrls: ['./basic.component.scss']
})
export class BasicComponent implements OnInit {
  // hr=['Option1', 'Option2', 'Option3'];
  // Developing=['Option3', 'Option5', 'Option6'];
  // Digital=['BPM','CRM','Nutshell'];
  // value;
  SelectedOption;
  options;

  constructor(private router: Router) { }

  ngOnInit() {
  }

  onChange(){
    if(this.SelectedOption==='Digital'){
      this.options=[
        {name:"BPM", value:"BPM"},
        {name:"CRM", value:"CRM"},
        {name:"NutShell", value:"Nutshell"}
      ];
    }else if(this.SelectedOption==='Developing'){
      this.options=[
        {name:"Option1", value:"Option1"},
        {name:"Option2", value:"Option2"},
        {name:"Option3", value:"Option3"}
      ];
    }else if(this.SelectedOption==='HR'){
      this.options=[
        {name:"Option4", value:"Option4"},
        {name:"Option5", value:"Option5"},
        {name:"Option6", value:"Option6"}
      ];
    }

    }

    nextPrev(){
      this.router.navigate(['/step2']);
    }
  }


