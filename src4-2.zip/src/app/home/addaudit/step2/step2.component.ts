import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-step2',
  templateUrl: './step2.component.html',
  styleUrls: ['./step2.component.scss']
})
export class Step2Component implements OnInit {

  constructor(private location: Location, private router: Router) { }

  ngOnInit() {
  }

  onBack() {
    this.location.back();
  }

  nextPrev() {
    this.router.navigate(['../step3']);
    console.log("PAge Navigated")
  }

}
