function vav(clicked_id) {
  
    d = clicked_id;
    // console.log(d);
   
    e=document.getElementById(d).value;
    console.log(e);
    console.log(d);
        res = d.slice(8, 10);
    console.log(res);
    total_point=document.getElementById('total_points'+res).value; 
    console.log(total_point);  

          
        if(e==='no'){ 
        document.getElementById('Attained'+res).setAttribute("value",0);

        }else if(e==='n/a'){
        document.getElementById('total_points'+res).setAttribute("value",0);
        document.getElementById('Attained'+res).setAttribute("value",0);
        }
        else if(e==='yes'){
          document.getElementById('Attained'+res).setAtdocument.getElementById('total_points'+res).setAttribute("value",total_points1); tribute("value",total_points1);
            
        }
}
        function addFields(){
            // Number of inputs to create
            var number = document.getElementById("member").value;
            // Container <div> where dynamic content will be placed
            var container = document.getElementById("containers");
            // Clear previous contents of the container
            while (container.hasChildNodes()) {
                container.removeChild(container.lastChild);
            }
            for (i=0;i<number;i++){
                // Append a node with a random text
                container.appendChild(document.createTextNode("Observations" + (i+1)));
                // Create an <input> element, set its type and name attributes
                var input = document.createElement("input");
                input.type = "text";
                input.name = "Observations[]" + i;
                container.appendChild(input);
                // Append a line break 
                container.appendChild(document.createElement("br"));
            }
        }
        function addNC(){
            // Number of inputs to create
            var number = document.getElementById("NC").value;
            // Container <div> where dynamic content will be placed
            var container = document.getElementById("container");
            // Clear previous contents of the container
            while (container.hasChildNodes()) {
                container.removeChild(container.lastChild);
            }
            for (i=0;i<number;i++){
              var h = document.createElement("H3");
              var t = document.createTextNode("NC# "+(i+1));
              h.appendChild(t);
              container.appendChild(h);
              container.appendChild(document.createElement("br"));
                // Append a node with a random text
                container.appendChild(document.createTextNode("Non Conformance Summary " + (i+1)));
                            
                // Create an <input> element, set its type and name attributes
                var input1 = document.createElement("input");
                input1.type = "text";
                input1.name = "NonConformanceSummary[]";
                container.appendChild(input1);
                 // ======================================
                container.appendChild(document.createTextNode("Type " + (i+1)));
                container.appendChild(document.createElement("br"));
                var input2 = document.createElement("input");
                input2.type = "text";
                input2.name= "type[]";
                container.appendChild(input2);
                // =========================================
                container.appendChild(document.createElement("br"));
                container.appendChild(document.createTextNode("Owner " + (i+1)));
                var input3 = document.createElement("input");
                input3.type = "text";
                input3.name = "owner[]";
                container.appendChild(input3);
                // =========================================
                // Append a line break 
                container.appendChild(document.createElement("br"));
                container.appendChild(document.createTextNode("Phase"+(i+1)));
                container.appendChild(document.createElement("br"));
                var input4 = document.createElement("select");
                input4.name="phase[]";
                container.appendChild(input4);                
                var options = ["Project Initiation","Project Planning","Project Monitoring","Requirement Analysis","Requirement Analysis","Change Management","Technical Design","Code Writing","Unit Testing","Internal Release","Test Planning & Designing","QA Acceptance & System Testing"];

                //Create and append the options
                for (var op = 0; op < options.length; op++) {
                    var option = document.createElement("option");
                    option.value = options[op];
                    option.text = options[op];
                    input4.appendChild(option);
                }
                
                container.appendChild(document.createElement("hr"));
            }
        }
   
var currentTab = 0; 
showTab(currentTab);
function showTab(n) {  
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
  fixStepIndicator(n)
}

function nextPrev(n) {
  var x = document.getElementsByClassName("tab");
  x[currentTab].style.display = "none";
  currentTab = currentTab + n;
  if (currentTab >= x.length) {
    document.getElementById("demoForm").submit();
    return false;
  }
  showTab(currentTab);
}
function validateForm() {
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  for (i = 0; i < y.length; i++) {
    if (y[i].value == "") {
      y[i].className += " invalid";
      valid = false;
    }
  }
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; 
}
function fixStepIndicator(n) { 
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");  } 
  x[n].className += " active";
}


function removeAllOptions(sel, removeGrp) {
    var len, groups, par;
    if (removeGrp) {
        groups = sel.getElementsByTagName('optgroup');
        len = groups.length;
        for (var i=len; i; i--) {
            sel.removeChild( groups[i-1] );
        }
    }    
    len = sel.options.length;
    for (var i=len; i; i--) {
        par = sel.options[i-1].parentNode;
        par.removeChild( sel.options[i-1] );
    }
}
function appendDataToSelect(sel, obj) {
    var f = document.createDocumentFragment();
    var labels = [], group, opts;
    
    function addOptions(obj) {
        var f = document.createDocumentFragment();
        var o;
        
        for (var i=0, len=obj.text.length; i<len; i++) {
            o = document.createElement('option');
            o.appendChild( document.createTextNode( obj.text[i] ) );
            
            if ( obj.value ) {
                o.value = obj.value[i];
            }
            
            f.appendChild(o);
        }
        return f;
    }    
    if ( obj.text ) {
        opts = addOptions(obj);
        f.appendChild(opts);
    } else {
        for ( var prop in obj ) {
            if ( obj.hasOwnProperty(prop) ) {
                labels.push(prop);
            }
        }        
        for (var i=0, len=labels.length; i<len; i++) {
            group = document.createElement('optgroup');
            group.label = labels[i];
            f.appendChild(group);
            opts = addOptions(obj[ labels[i] ] );
            group.appendChild(opts);
        }
    }
    sel.appendChild(f);
}
document.forms['demoForm'].elements['competency'].onchange = function(e) {
        var relName = 'tracks[]';    
   
    var relList = this.form.elements[ relName ];    
  	var obj = Select_List_Data[ relName ][ this.value ];    
     removeAllOptions(relList, true);    
   
    appendDataToSelect(relList, obj);
};

var Select_List_Data = {    
 
    'tracks[]': {               
        digital: {         
                text: ['BPM', 'CRM', 'NutShell'],
                value: ['BPM', 'CRM', 'Nutshell']           
        },
        developing: {
           text: ['Option1', 'Option2', 'Option3'],
            value: ['option1', 'option2', 'option3']        },
        hr: {
            text: ['Option4', 'Option5', 'Option6'],
            value: ['option4', 'option5', 'option6']
        }
    }
    
};

window.onload = function() {
    var form = document.forms['demoForm'];
  var sel = form.elements['competency'];
    sel.selectedIndex = 0;
    
    var relName = 'tracks[]';
    var rel = form.elements[ relName ];
    
   var data = Select_List_Data[ relName ][ sel.value ];
    
    appendDataToSelect(rel, data);
};
