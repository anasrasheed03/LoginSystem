<?php 
$response = file_get_contents('https://reqres.in/api/users');
print_r($response);
?>