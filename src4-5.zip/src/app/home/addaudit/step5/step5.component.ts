import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-step5',
  templateUrl: './step5.component.html',
  styleUrls: ['./step5.component.scss']
})
export class Step5Component implements OnInit {
  nc;
  constructor() { }

  ngOnInit() {
  }

  addNC(n:any){
    this.nc=n;
  }

}
