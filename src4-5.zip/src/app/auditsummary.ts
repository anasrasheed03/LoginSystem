export class Auditsummary{
        stage_name:string;
        SumTotal_Points: number;
        SumAttain_Points: number;
}